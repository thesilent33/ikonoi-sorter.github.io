dataSetVersion = "2022-02-01"; // Change this when creating a new data set version. YYYY-MM-DD format.
dataSet[dataSetVersion] = {};

dataSet[dataSetVersion].options = [
  {
    name: "Filter by Groups",
    key: "group",
    tooltip: "Check this to restrict per group.",
    checked: false,
    sub: [
		{ name: "=LOVE", tooltip: "=LOVE members only",key: "ikorabu" },
    { name: "≠ME", tooltip: "≠ME members only",key: "noimi" }
    ]
  },
  /*{
    name: "Filter by Sub Unit",
    key: "sub_unit",
    tooltip: "Check this to restrict members that appear in certain sub units.",
    checked: false,
    sub: [ 
		{ name: "5 Cantik", tooltip: "Sub unit consisting of Ushio Sarina, Takamoto Ayaka, Sasaki Kumi, Saito Kyoko and Kato Shiho", key: "5cantik" },
		{ name: "Hanachanzu", tooltip: "Sub unit consisting of Tomita Suzuka and Matsuda Konoka", key: "hanachanzu" },
		{ name: "Yancharu Family", tooltip: "Sub unit consisting of Higashimura Mei, Kanemura Miku, Kawata Hina and Nibu Akari for coupling song Cage from single Doremisolasido", key: "yancharu_family" },
		{ name: "Model 5", tooltip: "Sub unit consisting of 5 model of Hinatazaka46; Sasaki Mirei, Sasaki Kumi, Takamoto Ayaka, Kosaka Nao and Kato Shiho for coupling song Footstep from single Kyun", key: "model5" },
		{ name: "WakuWaku Peanuts", tooltip: "Unofficial sub unit consisting of Watanabe Miho and Tomita Suzuka", key: "waku2peanuts" },
		{ name: "GoriGori Donuts", tooltip: "Unofficial sub unit consisting of Watanabe Miho, Kanemura Miku and Nibu Akari", key: "gori2donuts" },
		{ name: "Saitama 3-nin Gumi", tooltip: "Unofficial sub unit consisting of 3 members from Saitama Prefecture; Watanabe Miho, Nibu Akari and Kanemura Miku", key: "saitama3ningumi" },
		{ name: "Hi Hi Sister", tooltip: "Unofficial sub unit consisting of Kawata Hina and Nibu Akari", key: "hihi_sister" }
    ]
  },*/
  {
    name: "Filter Activity Status",
    key: "activity_status",
    tooltip: "Check this to restrict members by activity status.",
    checked: false,
    sub: [
		{ name: "Active Member", tooltip: "Member who currently active as member", key: "active" },
		{ name: "Graduated", tooltip: "Member who already graduated", key: "graduated" }
    ]
  }
];

dataSet[dataSetVersion].characterData = [
  // ≠ME members

  {
    name: "Ogi Hana",
    img: "0Vh63bX/ogi-hana.jpg",
    opts: {
      group: [ "noimi" ],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Ochiai Kirari",
    img: "NLjV49Z/ochiai-kirari.jpg",
    opts: {
      group: [ "noimi" ],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Kanisawa Moeko",
    img: "WK8MXn9/kanisawa-moeko.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Kawaguchi Natsune",
    img: "qj9gbZx/kawaguchi-natsune.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: ["", ""], activity_status: ["active"]
    }
  },
  {
    name: "Kawanago Natsumi",
    img: "TvfNhkb/kawanago-natsumi.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: ["", ""], activity_status: ["active"]
    }
  },
  {
    name: "Sakurai Momo",
    img: "q584Jrz/sakurai-momo.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Suganami Mirei",
    img: "w0wFx43/suganami-mirei.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: ["", ""], activity_status: ["active"]
    }
  },
  {
    name: "Suzuki Hitomi",
    img: "51sms39/suzuki-hitomi.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Tanizaki Saya",
    img: "K6XVvQR/tanizaki-saya.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Tomita Nanaka",
    img: "rtyTmcg/tomita-nanaka.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Nagata Shiori",
    img: "3C6n6v7/nagata-shiori.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Honda Miyuki",
    img: "rxkPLXq/honda-miyuki.jpg",
    opts: {
      group: ["noimi"],
      sub_unit: [""], activity_status: ["active"]
    }
  },

  // =LOVE members
  
  {
    name: "Otani Emiri",
    img: "R0hvpKQ/otani-emiri-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Oba Hana",
    img: "hmSL664/oba-hana-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Otoshima Risa",
    img: "CvwBKj6/otoshima-risa-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Saito Kiara",
    img: "19c5pTV/saito-kiara-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Saito Nagisa",
    img: "pjQtbQG/saito-nagisa-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Sasaki Maika",
    img: "vZ8vRVQ/sasaki-maika-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Satake Nonno",
    img: "BwdwDZv/satake-nonno-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["graduated"]
    }
  },
  {
    name: "Takamatsu Hitomi",
    img: "rcfyc0F/takamatsu-hitomi-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Takiwaki Shoko",
    img: "nkQHwq3/takiwaki-shoko-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Noguchi Iori",
    img: "60p4Stj/noguchi-iori-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Morohashi Sana",
    img: "kqSrHhM/morohashi-sana-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  },
  {
    name: "Yamamoto Anna",
    img: "y59x7rJ/yamamoto-anna-original.jpg",
    opts: {
      group: ["ikorabu"],
      sub_unit: [""], activity_status: ["active"]
    }
  }

];
